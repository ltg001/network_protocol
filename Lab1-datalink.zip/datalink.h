//#define GOBACKN
#define SELECTIVE

/* FRAME kind */
#define FRAME_DATA 1
#define FRAME_ACK 2
#define FRAME_NAK 3

#ifdef GOBACKN

#define DATA_TIMER 3000
#define ACK_TIMER 280
#define MAX_SEQ 7

static unsigned char buffer[MAX_SEQ + 1][PKT_LEN];
static unsigned char nbuffered = 0;
static unsigned char ack_expected = 0;		 // Lowerbound of Sending Window
static unsigned char next_frame_to_send = 0; // Upperbound of Sending Window
static unsigned char frame_expected = 0;	 // L/U bound of Receiving Window

#endif

#ifdef SELECTIVE
#define DATA_TIMER 3000
#define ACK_TIMER 280
#define MAX_SEQ 87
#define NR_BUFS ((MAX_SEQ + 1) / 2)

static unsigned char nbuffered = 0;
static bool arrived[NR_BUFS];
static unsigned char recv_buffer[NR_BUFS][PKT_LEN];
static unsigned char send_buffer[NR_BUFS][PKT_LEN];

static unsigned char ack_expected = 0;		 // Lowerbound of Sending Window
static unsigned char next_frame_to_send = 0; // Upperbound of Sending Window
static unsigned char frame_expected = 0;	 // L bound of Receiving Window
static unsigned char too_far = NR_BUFS;		 // U bound of Receiving Window
#endif
/*
 DATA Frame
 +=========+========+========+===============+========+
 | KIND(1) | SEQ(1) | ACK(1) | DATA(240~256) | CRC(4) |
 +=========+========+========+===============+========+

 ACK Frame
 +=========+========+========+
 | KIND(1) | ACK(1) | CRC(4) |
 +=========+========+========+

 NAK Frame
 +=========+========+========+
 | KIND(1) | ACK(1) | CRC(4) |
 +=========+========+========+
 */
typedef char bool;
#define true 1
#define false 0

struct FRAME
{
	unsigned char kind; // FRAME_DATA
	unsigned char ack;
	unsigned char seq;
	unsigned char data[PKT_LEN];
	unsigned int padding;
};

static bool phl_ready = false;
static bool no_nak = true;
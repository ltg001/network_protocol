#include <stdio.h>
#include <string.h>

#include "protocol.h"
#include "datalink.h"

// Add checksum to the end of a frame,and Put it to physical layer
static void put_frame(unsigned char *frame, int len)
{
	*(unsigned int *)(frame + len) = crc32(frame, len);
	send_frame(frame, len + 4);
	phl_ready = false;
}

static void send_data_frame(unsigned char frame_nr,
							unsigned char frame_expected,
							unsigned char *packet)
{
	struct FRAME s;

	s.kind = FRAME_DATA;
	s.seq = frame_nr;
	s.ack = (frame_expected + MAX_SEQ) % (MAX_SEQ + 1);

	memcpy(s.data, packet, PKT_LEN);

	dbg_frame("<-Send DATA %d %d, ID %d\tWindows %d\t\t\tphy_seq_length:%d\n",
			  s.seq, s.ack, *(short *)s.data,
			  (next_frame_to_send - ack_expected + MAX_SEQ + 2) % (MAX_SEQ + 1),
			  phl_sq_len());

	put_frame((unsigned char *)&s, 3 + PKT_LEN);
#ifdef SELECTIVE
	start_timer(frame_nr % NR_BUFS, DATA_TIMER);
#endif

#ifdef GOBACKN
	start_timer(frame_nr, DATA_TIMER);
#endif
	stop_ack_timer();
}

static void send_ack_frame(unsigned char frame_expected)
{
	struct FRAME s;

	s.kind = FRAME_ACK;
	s.ack = (frame_expected + MAX_SEQ) % (MAX_SEQ + 1);

	dbg_frame("Send ACK  %d\n", s.ack);

	put_frame((unsigned char *)&s, 2);
	stop_ack_timer();
}

static void send_nak_frame(unsigned char frame_expected)
{
	struct FRAME s;

	s.kind = FRAME_NAK;
	s.ack = (frame_expected + MAX_SEQ) % (MAX_SEQ + 1);

	no_nak = false;
	dbg_frame("Send NAK %d\n", s.ack);

	// sizeof (kind + ack)
	put_frame((unsigned char *)&s, 2);
	stop_ack_timer();
}

static bool between(unsigned char a, unsigned char b, unsigned char c)
{
	// a <= b < c circularly
	return (
		((a <= b) && (b < c)) ||
		((c < a) && (a <= b)) ||
		((b < c) && (c < a)));
}

#ifdef GOBACKN

/*
原本的协议中有总是捎带确认的假设，而且不使用nak
本协议使用了ack、nak、timeout（无用）、ack_time_out
现在效率低的原因，当有nak或者timeout事件发生时，重传的包一下子扔给物理层，
捎带的ack不能确认
*/

int main(int argc, char **argv)
{
	int event, arg;
	struct FRAME f;
	int len = 0;

	protocol_init(argc, argv);
	lprintf("Designed by Jiang Yanjun/Xu Yiru, build: " __DATE__ "  "__TIME__
			"\n");
	disable_network_layer();

	while (true)
	{
		event = wait_for_event(&arg);

		switch (event)
		{

			//network layer is ready,so you want to send a data frame.
		case NETWORK_LAYER_READY:

			get_packet(buffer[next_frame_to_send]);
			nbuffered++;
			send_data_frame(next_frame_to_send, frame_expected,
							buffer[next_frame_to_send]);

			inc(next_frame_to_send);
			phl_ready = false;
			break;

		case PHYSICAL_LAYER_READY:

			phl_ready = true;
			break;

		case FRAME_RECEIVED:

			len = recv_frame((unsigned char *)&f, sizeof f);
			if (len < 5 || crc32((unsigned char *)&f, len) != 0)
			{
				dbg_event("**** Receiver Error, Bad CRC Checksum\t"
						  "seq %d -  ack %d\n",
						  f.seq, f.ack);
				if (no_nak)
				{
					send_nak_frame(frame_expected);
				}
				break;
			}
			if (f.kind == FRAME_ACK)
				dbg_frame("Recv ACK  %d\n", f.ack);
			if (f.kind == FRAME_NAK)
				dbg_frame("Recv NAK  %d\n", f.ack);
			if (f.kind == FRAME_DATA)
			{
				dbg_frame("Recv DATA %d %d, ID %d\n", f.seq, f.ack,
						  *(short *)f.data);
				if (f.seq == frame_expected)
				{
					/*get_packet和put_packet都直接把数据段长度设置为256
                    因为protocol.c中有函数判断len-7不等于256的话直接丢弃，
                    说明没必要加字节计数域.642行*/
					put_packet(f.data, len - 7);
					no_nak = true;
					inc(frame_expected);
					start_ack_timer(ACK_TIMER);
				}
				else if (no_nak)
				{
					send_nak_frame(frame_expected);
				}
			}

			while (between(ack_expected, f.ack, next_frame_to_send))
			{
				nbuffered--;
				stop_timer(ack_expected);
				inc(ack_expected);
			}

			if (f.kind == FRAME_NAK)
			{
				stop_timer(ack_expected + 1);
				goto resend;
			}
			break;

		case DATA_TIMEOUT:
			dbg_event("---- DATA %d timeout\n", arg);

		resend:
			next_frame_to_send = ack_expected;
			for (unsigned char i = 0; i < nbuffered; i++)
			{
				send_data_frame(next_frame_to_send, frame_expected,
								buffer[next_frame_to_send]);
				inc(next_frame_to_send);
				phl_ready = false;
			}
			phl_ready = false;
			break;

		case ACK_TIMEOUT:
			dbg_event("------------------------ ACK %d timeout\n",
					  (frame_expected + MAX_SEQ) % (MAX_SEQ + 1));
			send_ack_frame(frame_expected);
			break;
		}

		if (nbuffered < MAX_SEQ && phl_ready)
			enable_network_layer();
		else
			disable_network_layer();
	}
}

#endif

#ifdef SELECTIVE

/*
使用了ack、nak、timeout、ack_time_out
*/

int main(int argc, char **argv)
{
	//初始化
	nbuffered = 0; //初始没有输出帧被缓存
	int i;
	for (i = 0; i < NR_BUFS; i++) //初始时没有输入帧被缓存
		arrived[i] = false;
	int event, arg;
	struct FRAME f;
	int len = 0;

	protocol_init(argc, argv);
	lprintf("Designed by Jiang Yanjun/Xu Yiru, build: " __DATE__ "  "__TIME__
			"\n");

	disable_network_layer();

	while (true)
	{
		event = wait_for_event(&arg);

		switch (event)
		{
		case NETWORK_LAYER_READY:
			//从网络层获取一帧放入输出缓存中
			get_packet(send_buffer[next_frame_to_send % NR_BUFS]);
			nbuffered++;
			send_data_frame(next_frame_to_send, frame_expected,
							send_buffer[next_frame_to_send % NR_BUFS]);
			inc(next_frame_to_send); //将发送方窗口上限+1
									 //phl_ready = false;
			phl_ready = false;
			break;

		case PHYSICAL_LAYER_READY:
			phl_ready = true;
			break;

		case FRAME_RECEIVED:
			len = recv_frame((unsigned char *)&f, sizeof f);
			//如果校验发生错误，说明传输过程中出现了问题，直接发送nak
			if (len < 5 || crc32((unsigned char *)&f, len) != 0)
			{
				dbg_event("**** Receiver Error, Bad CRC Checksum\n");
				if (no_nak)
				{
					send_nak_frame(frame_expected);
				}
				break;
			}

			//如果是ack帧的话，由于所有帧都含有ack帧，因此统一处理
			if (f.kind == FRAME_ACK)
				dbg_frame("Recv ACK  %d\n", f.ack);

			if (f.kind == FRAME_DATA)
			{
				//如果收到的是不需要的帧则返回nak
				if ((f.seq != frame_expected) && no_nak)
					send_nak_frame(frame_expected);
				else
					start_ack_timer(ACK_TIMER);

				if (between(frame_expected, f.seq, too_far) &&
					(arrived[f.seq % NR_BUFS] == false))
				//如果收到的帧在接收方窗口内且这一帧未被接收过
				{
					dbg_frame("->Recv DATA %d %d, ID %d\n", f.seq, f.ack,
							  *(short *)f.data);
					//标记该帧为已接受
					arrived[f.seq % NR_BUFS] = true;
					//将接收到的帧的data域复制至输入缓存中
					memcpy(recv_buffer[f.seq % NR_BUFS], f.data, PKT_LEN);
					//当收到接收方窗口下界的一帧时，对这一帧以及之后收到的帧进行处理
					while (arrived[frame_expected % NR_BUFS])
					{
						//将输入缓存送至网络层
						put_packet(
							recv_buffer[frame_expected % NR_BUFS], len - 7);
						no_nak = true;
						arrived[frame_expected % NR_BUFS] = false;
						inc(frame_expected); //将窗口前移一位
						inc(too_far);
						//如果ack_timer超时则发送ack帧
						start_ack_timer(ACK_TIMER);
					}
				}
			}
			//如果收到的是nak帧且ack的下一帧在发送方窗口里，则发送ack的下一帧
			if ((f.kind == FRAME_NAK) &&
				between(ack_expected, (f.ack + 1) % (MAX_SEQ + 1),
						next_frame_to_send))
			{
				send_data_frame((f.ack + 1) % (MAX_SEQ + 1), frame_expected,
								send_buffer
									[((f.ack + 1) % (MAX_SEQ + 1)) % NR_BUFS]);
				dbg_frame("Recv NAK with ACK %d\n", f.ack);
			}

			while (between(ack_expected, f.ack, next_frame_to_send))
			{
				nbuffered--;
				stop_timer(ack_expected % NR_BUFS);
				inc(ack_expected);
			}

			break;

		case DATA_TIMEOUT:
			dbg_event("------------------------ DATA %d timeout\n", arg);
			if (!between(ack_expected, arg, next_frame_to_send))
				arg = arg + NR_BUFS;
			send_data_frame(arg, frame_expected, send_buffer[arg % NR_BUFS]);
			phl_ready = false;
			break;

		case ACK_TIMEOUT:
			dbg_event("------------------------ ACK %d timeout\n",
					  (frame_expected + MAX_SEQ) % (MAX_SEQ + 1));
			send_ack_frame(frame_expected);
			break;
		}

		if (nbuffered < NR_BUFS && phl_ready)
			enable_network_layer();
		else
			disable_network_layer();
	}
}

#endif
